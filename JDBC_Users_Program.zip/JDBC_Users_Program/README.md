# JDBC Database Connection Lab (1.1)

## Aim
Connect to the MySQL database `mydatabase` using JDBC, retrieve all records from
the `users` table, and display each user's ID, username, and email.

## Requirements
- Java JDK installed
- MySQL Server running
- MySQL Connector/J JDBC driver
- A database named `mydatabase` with a `users` table containing `id`, `username`,
  and `email` columns

## Example database setup
Run these SQL statements in MySQL if you need sample data:

```sql
CREATE DATABASE IF NOT EXISTS mydatabase;
USE mydatabase;

CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL
);

INSERT INTO users (id, username, email) VALUES
(1, 'johndoe', 'johndoe@example.com'),
(2, 'janedoe', 'janedoe@example.com'),
(3, 'alice', 'alice@example.com');
```

If the table already contains these IDs, do not run the sample INSERT statements
again.

## Configure your credentials
Open `src/JDBCConnect.java` and replace `your_password` with your MySQL password.
If your MySQL username is not `root`, change `USERNAME` too.

## Compile and run
Make sure the MySQL Connector/J JAR is available. For example, if it is stored
as `mysql-connector-j.jar` in this project folder:

### macOS / Linux
```bash
javac -cp ".:mysql-connector-j.jar" -d out src/JDBCConnect.java
java -cp "out:mysql-connector-j.jar" JDBCConnect
```

### Windows
```bat
javac -cp ".;mysql-connector-j.jar" -d out src/JDBCConnect.java
java -cp "out;mysql-connector-j.jar" JDBCConnect
```

The driver JAR filename may differ depending on the version you downloaded.

## Expected output
```text
Connected to the database successfully.
User ID: 1, Username: johndoe, Email: johndoe@example.com
User ID: 2, Username: janedoe, Email: janedoe@example.com
User ID: 3, Username: alice, Email: alice@example.com
```

The displayed records depend on the data in your database. The program uses
try-with-resources to close the connection, statement, and result set automatically.
