Save your actual execution screenshot in this folder as output_1.png or output_1.jpg.
The program output cannot be captured here because it depends on your local MySQL setup.
